package com.example.utsprincessparade

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.content.Intent





class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Mengatur listener untuk setiap tombol princess
        val buttonMoana = findViewById<Button>(R.id.button_moana)
        buttonMoana.setOnClickListener {
            bukaDetailActivity("Moana", R.drawable.moana, getString(R.string.moana_description))
        }

        val buttonMulan = findViewById<Button>(R.id.button_mulan)
        buttonMulan.setOnClickListener {
            bukaDetailActivity("Mulan", R.drawable.mulan, getString(R.string.mulan_description))
        }

        val buttonTangled = findViewById<Button>(R.id.button_tangled)
        buttonTangled.setOnClickListener {
            bukaDetailActivity("Tangled", R.drawable.tangled, getString(R.string.tangled_description))
        }

        val buttonBrave = findViewById<Button>(R.id.button_brave)
        buttonBrave.setOnClickListener {
            bukaDetailActivity("Brave", R.drawable.brave, getString(R.string.brave_description))
        }

        val buttonSnowwhite = findViewById<Button>(R.id.button_snowwhite)
        buttonSnowwhite.setOnClickListener {
            bukaDetailActivity("Snow White", R.drawable.snow_white, getString(R.string.snowwhite_description))
        }

        val buttonCinderella = findViewById<Button>(R.id.button_cinderella)
        buttonCinderella.setOnClickListener {
            bukaDetailActivity("Cinderella", R.drawable.cinderella, getString(R.string.cinderella_description))
        }

        val buttonThesleepingbeauty = findViewById<Button>(R.id.button_thesleepingbeauty)
        buttonThesleepingbeauty.setOnClickListener {
            bukaDetailActivity("The Sleeping Beauty", R.drawable.the_sleeping_beauty, getString(R.string.thesleepingbeauty_description))
        }

        val buttonBeautyandthebeast = findViewById<Button>(R.id.button_beautyandthebeast)
        buttonBeautyandthebeast.setOnClickListener {
            bukaDetailActivity("Beauty and the beast", R.drawable.beauty_and_the_beast, getString(R.string.beautyandthebeast_description))
        }

        val buttonFrozen = findViewById<Button>(R.id.button_frozen)
        buttonFrozen.setOnClickListener {
            bukaDetailActivity("Frozen", R.drawable.frozen, getString(R.string.frozen_description))
        }

        val buttonThelittlemermaid = findViewById<Button>(R.id.button_thelittlemermaid)
        buttonThelittlemermaid.setOnClickListener {
            bukaDetailActivity("The Little Mermaid", R.drawable.thelittlemermaid, getString(R.string.thelittlemermaid_description))
        }

        val buttonPrincessandthefrog = findViewById<Button>(R.id.button_princessandthefrog)
        buttonPrincessandthefrog.setOnClickListener {
            bukaDetailActivity("Princess And The Frog", R.drawable.princessandthefrog, getString(R.string.princessandthefrog_description))
        }

        val buttonAladdin = findViewById<Button>(R.id.button_aladdin)
        buttonAladdin.setOnClickListener {
            bukaDetailActivity("Aladdin", R.drawable.aladdin, getString(R.string.aladdin_description))
        }

        val buttonPocahontas = findViewById<Button>(R.id.button_pocahontas)
        buttonPocahontas.setOnClickListener {
            bukaDetailActivity("Pocahontas", R.drawable.pocahontas, getString(R.string.pocahontas_description))
        }
    }

    private fun bukaDetailActivity(nama: String, gambar: Int, deskripsi: String) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra("NAMA_PRINCESS", nama)
        intent.putExtra("GAMBAR_PRINCESS", gambar)
        intent.putExtra("DESKRIPSI_PRINCESS", deskripsi)
        startActivity(intent)
    }



}