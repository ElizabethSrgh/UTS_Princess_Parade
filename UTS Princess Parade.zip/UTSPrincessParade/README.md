Nama Aplikasi:
Princess parade

Deskripsi Aplikasi:
"Princess Parade" adalah aplikasi yang dirancang untuk para penggemar film Disney Princess. Aplikasi ini memberikan rekomendasi judul-judul film Disney Princess beserta deskripsi singkat dari setiap film, sehingga pengguna dapat menemukan cerita favorit atau menemukan inspirasi untuk menonton film baru.
